package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Browser;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
                            implements AdapterView.OnItemSelectedListener {

    private static final String TRACE_TAG = "TRACE";
    private static final String LOG_TAG = MainActivity.class.getSimpleName();
    private static final String jsonQueryString = "{\"items\":[{\"department\":\"CSD\",\"courseNbr\":\"110\",\"quarterName\":\"Spring 21\",\"courseTitle\":\"COMPUTER PRGRM PYTHON\",\"courseDescription\":" +
            "\"A general introduction to concepts related to designing and writing computer programs and procedures. Students learn to apply programming logic and problem-solving techniques, algorithmic" +
            "thinking, and concepts such as data types and data structures using Python.\",\"credits\":\"5.0\",\"preCoRequisites\":\"ENGL 093 (or placement into ENGL 099 or higher) and MATH 090 (or " +
            "placement into MATH 099 or higher)\",\"courseSections\":[{\"department\":\"CSD\",\"courseNbr\":\"110\",\"quarterName\":\"Spring 21\",\"sectionCode\":\"R1\",\"itemNbr\":\"9630\",\"days\":\"MW\"," +
            "\"timeLocation\":\"12:00 PM - 01:50 PM @ ZOOM\",\"instructor\":\"Zerrouki M\",\"labFee\":\"85.0\"}]}," +
            "{\"department\":\"CSD\",\"courseNbr\":\"111\",\"quarterName\":\"Spring 21\",\"courseTitle\":\"COMPUTER PROG FUNDAMENTL\",\"courseDescription\":\"A general introduction to concepts related to designing" +
            "and writing computer programs and procedures. Students study problem-solving techniques, algorithmic thinking, programming logic, and concepts such as data types, data structures, and object-oriented programming.\"," +
            "\"credits\":\"5.0\",\"preCoRequisites\":\"Prerequisites: MATH 090 (or placement into MATH 099 or higher) and ENGL 093 (or placement into ENGL 099 or higher)\",\"courseSections\":[{\"department\":\"CSD\",\"courseNbr\":"+
            "\"111\",\"quarterName\":\"Spring 21\",\"sectionCode\":\"R1\",\"itemNbr\":\"9635\",\"days\":\"MW\",\"timeLocation\":\"04:00 PM - 05:50 PM @ ZOOM\",\"instructor\":\"Zerrouki M\",\"labFee\":\"85.0\"},{\"department\":\"CSD\","+
            "\"courseNbr\":\"111\",\"quarterName\":\"Spring 21\",\"sectionCode\":\"R2\",\"itemNbr\":9640,\"days\":\"TTh\",\"timeLocation\":\"12:00 PM - 01:50 PM @ ZOOM\",\"instructor\":\"Zerrouki M\",\"labFee\":\"85.0\"}]}]}";
    String mSearchDept;
    String mSearchQuarter;
    String mSearchCourse;
    String mSearchItem;

    public static final String SEARCH_DEPT =
            "com.example.android.FinalProject.DEPT";
    public static final String SEARCH_QUARTER =
            "com.example.android.FinalProject.QUARTER";
    public static final String SEARCH_COURSE =
            "com.example.android.FinalProject.COURSE";
    public static final String SEARCH_ITEM =
            "com.example.android.FinalProject.ITEM";
    public static final String JSON_QUERY_RESULT =
            "com.example.android.FinalProject.JSONRESULTSTRING";

    private Spinner spinnerDepartment;
    private Spinner spinnerQuarter;
    private Spinner spinnerCourse;
    private Spinner spinnerItem;
    int currDeptPos = 0;
    int currQuarterPos = 0;
    int currCoursePos = 0;
    int currItemPos = 0;
    String currDeptName;
    String currQuarterName;
    String currCourseNbr;
    String currItemNbr;
    ArrayAdapter deptAdapter;
    ArrayAdapter quartersAdapter;
    ArrayAdapter courseAdapter;
    ArrayAdapter itemAdapter;

    boolean initializing = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinnerDepartment = findViewById(R.id.spinnerDepartment);
        spinnerQuarter = findViewById(R.id.spinnerQuarter);
        spinnerCourse = findViewById(R.id.spinnerCourse);
        spinnerItem = findViewById(R.id.spinnerItem);

        String[] deptNames = getResources().getStringArray(R.array.departments_array);
        deptAdapter = new ArrayAdapter(this,
                android.R.layout.simple_spinner_item,
                deptNames);
        deptAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDepartment.setAdapter(deptAdapter);
        currDeptName = deptNames[currDeptPos];

        String[] quarterNames = getResources().getStringArray(R.array.quarters_array);
        quartersAdapter = new ArrayAdapter(this,
                android.R.layout.simple_spinner_item,
                quarterNames);
        quartersAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerQuarter.setAdapter(quartersAdapter);
        currQuarterName = quarterNames[currQuarterPos];

        String[] courseNbrs = getResources().getStringArray(R.array.courses_array);
        courseAdapter = new ArrayAdapter(this,
                android.R.layout.simple_spinner_item,
                courseNbrs);
        courseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCourse.setAdapter(courseAdapter);
        currCourseNbr = courseNbrs[currCoursePos];

        String[] itemNbrs = getResources().getStringArray(R.array.items_array);
        itemAdapter = new ArrayAdapter(this,
                android.R.layout.simple_spinner_item,
                itemNbrs);
        itemAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerItem.setAdapter(itemAdapter);
        currItemNbr = itemNbrs[currItemPos];

        spinnerDepartment.setOnItemSelectedListener(this);
        spinnerQuarter.setOnItemSelectedListener(this);
        spinnerCourse.setOnItemSelectedListener(this);
        spinnerItem.setOnItemSelectedListener(this);
        initializing = false;

    }

    private void reInitializeSpinners() {

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Log.d(TRACE_TAG,"Entered onItemSelected, position = " + position + ",parent.getId() = " + parent.getId());
        Log.d(TRACE_TAG, "Initializing = " + initializing);
        if (!initializing) {
            if (parent.getId() == R.id.spinnerDepartment) {
                String valueFromSpinner = parent.getItemAtPosition(position).toString();
//                Toast toast = Toast.makeText(this, "Dept " + valueFromSpinner + " selected...pos =" + position,
//                        Toast.LENGTH_LONG);
//                toast.show();
                currDeptPos = position;
                currDeptName = valueFromSpinner;
            } else if (parent.getId() == R.id.spinnerQuarter) {
                String valueFromSpinner = parent.getItemAtPosition(position).toString();
//                Toast toast = Toast.makeText(this, "Quarter " + valueFromSpinner + " selected...",
//                        Toast.LENGTH_SHORT);
//                toast.show();
                currQuarterPos = position;
                currQuarterName = valueFromSpinner;
            }
            if (parent.getId() == R.id.spinnerCourse) {
                String valueFromSpinner = parent.getItemAtPosition(position).toString();
//                Toast toast = Toast.makeText(this, "Course " + valueFromSpinner + " selected...pos =" + position,
//                        Toast.LENGTH_SHORT);
//                toast.show();
                currCoursePos = position;
                currCourseNbr = valueFromSpinner;
            } else if (parent.getId() == R.id.spinnerItem) {
                String valueFromSpinner = parent.getItemAtPosition(position).toString();
//                Toast toast = Toast.makeText(this, "Item " + valueFromSpinner + " selected...",
//                        Toast.LENGTH_SHORT);
//                toast.show();
                currItemPos = position;
                currItemNbr = valueFromSpinner;
            }
        } // of !initializing
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
//        Log.d(TRACE_TAG,"Entered onNothingSelected");
//        if (parent.getId() == R.id.spinnerDepartment) {
//            String valueFromSpinner = parent.getItemAtPosition(currDeptPos).toString();
//            Toast toast = Toast.makeText(this,"Dept " + valueFromSpinner + " selected...pos =" + currDeptPos,
//                    Toast.LENGTH_SHORT);
//            toast.show();
//        } else
//        if (parent.getId() == R.id.spinnerQuarter) {
//            String valueFromSpinner = parent.getItemAtPosition(currQuarterPos).toString();
//            Toast toast = Toast.makeText(this,"Quarter " + valueFromSpinner + " selected...pos =" + currDeptPos,
//                    Toast.LENGTH_SHORT);
//            toast.show();
//        }
    }

    public void resetToStart(View view) {
        Log.d(TRACE_TAG,"Entered resetToStart");
        initializing = true;
        reInitializeSpinners();
        initializing = false;
        String toastStr = "Initialized to " + currQuarterName + " " + currDeptName + currCourseNbr +
                currItemNbr;
        Log.d(TRACE_TAG, "Toast msg = " + toastStr);
        Toast toast = Toast.makeText(this,toastStr,Toast.LENGTH_SHORT);
        toast.show();
    }

    public void searchClasses(View view) {
        Log.d(TRACE_TAG, "Entered searchClasses");
        String toastStr = "Search " + currQuarterName + " " + currDeptName + currCourseNbr +
                currItemNbr;
        Log.d(TRACE_TAG, "Toast msg = " + toastStr);
        Toast toast = Toast.makeText(this, toastStr, Toast.LENGTH_SHORT);
        toast.show();

        Intent intent = new Intent(MainActivity.this, ClassListActivity.class);
//        mSearchDept = currDeptName.substring(0,currDeptName.indexOf(' '));
//        mSearchQuarter = currQuarterName;
//        mSearchCourse = currCourseNbr;
//        mSearchItem = currItemNbr;
//
//        intent.putExtra(SEARCH_DEPT, mSearchDept);
//        intent.putExtra(SEARCH_QUARTER, mSearchQuarter);
//        intent.putExtra(SEARCH_COURSE, mSearchCourse);
//        intent.putExtra(SEARCH_ITEM, mSearchItem);
//        String jsonQueryResult = getResources().getString(R.string.queryString);
        String jsonQueryResult = jsonQueryString;
        Log.d(TRACE_TAG, "Putting Extra jsonQueryResult = " + jsonQueryResult);
        intent.putExtra(JSON_QUERY_RESULT,jsonQueryResult);
        startActivity(intent);
    }
}