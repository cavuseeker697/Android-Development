package com.example.finalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import static com.example.finalproject.MainActivity.JSON_QUERY_RESULT;

public class ClassListActivity extends AppCompatActivity
                                implements ItemAdapter.ListItemClickListener {

    private static final String TRACE_TAG = "TRACE";
    private static final String LOG_TAG = ClassListActivity.class.getSimpleName();

    TextView mClassTitle;
    String jsonQueryResult;
    String mSearchDept;
    String mSearchQuarter;
    String mSearchCourseNbr;
    String mSearchItem;
    String mSearchTitle;
    String mSearchDesc;
    String mSearchCredits;
    JSONObject mCurrentClassJSONObject;
    RecyclerView mRecyclerView;
    ItemAdapter mAdapter;

    private ArrayList mClassList = new ArrayList<ClassEntryModel>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_view);

        mRecyclerView = findViewById(R.id.recyclerView);
        Intent intent = getIntent();
//        String mSearchDept = intent.getStringExtra(SEARCH_DEPT);
//        String mSearchQuarter = intent.getStringExtra(SEARCH_QUARTER);
//        String mSearchCourse = intent.getStringExtra(SEARCH_COURSE);
//        String mSearchItem = intent.getStringExtra(SEARCH_ITEM);
//
//        String searchString = "Search Dept=" + mSearchDept + ",Quarter=" + mSearchQuarter +
//                ",Course=" + mSearchCourse + ",Item=" + mSearchItem;
        jsonQueryResult = intent.getStringExtra(JSON_QUERY_RESULT);
        Log.d(TRACE_TAG, "In OnCreate Class List, json string = " + jsonQueryResult);
        String firstEntry = "";
        try {
            JSONObject jsonObject = new JSONObject(jsonQueryResult);
            JSONArray itemsArray = jsonObject.getJSONArray("items");
            Log.d(TRACE_TAG, "Parsing JSON, # of items = " + itemsArray.length());
            int len = itemsArray.length();
            // For now, just get the first one
            if (len > 0) {
                for (int i = 0; i<len; i++) {  // Will loop through to create recycler view
                    mCurrentClassJSONObject = itemsArray.getJSONObject(i);
                    try {
                        mSearchDept = mCurrentClassJSONObject.getString("department");
                        mSearchCourseNbr = mCurrentClassJSONObject.getString("courseNbr");
                        mSearchQuarter = mCurrentClassJSONObject.getString("quarterName");
                        mSearchTitle = mCurrentClassJSONObject.getString("courseTitle");
                        mSearchDesc = mCurrentClassJSONObject.getString("courseDescription");
                        mSearchCredits = mCurrentClassJSONObject.getString("credits");
                        mClassList.add(new ClassEntryModel(mSearchDept,
                                                            mSearchCourseNbr,
                                                            mSearchTitle,
                                                            mSearchDesc,
                                                            mSearchCredits));
                    } catch (JSONException e) {
                        Log.d(TRACE_TAG, "JSON Exception #2 - First entry" + e.getMessage());
                    }
                }
            }
        } catch (JSONException e) {
            Log.d(TRACE_TAG, "JSON Exception #1 - Outer loop " + e.getMessage());
            }
//        firstEntry = "Dept=" + mSearchDept + ",Quarter=" + mSearchQuarter +
//              ",Course=" + mSearchCourse;

        mAdapter = new ItemAdapter(this,mClassList,this);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

    }

    public void onListItemClick (int clickedItemIndex) {

        Intent intent = new Intent(ClassListActivity.this, ClassDetailPage.class);
//        mSearchDept = currDeptName.substring(0,currDeptName.indexOf(' '));
//        mSearchQuarter = currQuarterName;
//        mSearchCourse = currCourseNbr;
//        mSearchItem = currItemNbr;
//
//        intent.putExtra(SEARCH_DEPT, mSearchDept);
//        intent.putExtra(SEARCH_QUARTER, mSearchQuarter);
//        intent.putExtra(SEARCH_COURSE, mSearchCourse);
//        intent.putExtra(SEARCH_ITEM, mSearchItem);
//        String jsonQueryResult = getResources().getString(R.string.queryString);

        intent.putExtra("Current_Class_Object", (Serializable) mClassList.get(clickedItemIndex));
        Log.d(TRACE_TAG, "Putting Extra mClassList(" + clickedItemIndex + ")");
        startActivity(intent);

    }
}
