package com.example.finalproject;

import org.json.JSONObject;

import java.io.Serializable;

public class ClassEntryModel
    implements Serializable {

    public String classDept;
    public String classCourseNbr;
    public String classTitle;
    public String classDesc;
    public String classCredits;

    public ClassEntryModel (String classDept,
                            String classCourseNbr,
                            String classTitle,
                            String classDesc,
                            String classCredits) {
        this.classDept = classDept;
        this.classCourseNbr = classCourseNbr;
        this.classTitle = classTitle;
        this.classDesc = classDesc;
        this.classCredits = classCredits;
    }
    String getClassDept() {return this.classDept;}
    String getClassCourseNbr() {return this.classCourseNbr;}
    String getClassTitle() {return this.classTitle;}
    String getClassDesc() {return this.classDesc;}
    String getClassCredits() {return this.classCredits;}

}
