package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ClassDetailPage extends AppCompatActivity {

    private static final String TRACE_TAG = "TRACE";
    private static final String LOG_TAG = ClassDetailPage.class.getSimpleName();

    TextView mCourseNumber;
    TextView mCourseTitle;
    TextView mCourseDesc;
    TextView mCourseCredits;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_detail_listing);

        // courseNumber is the concatentation of courseDept and courseNbr.
        // if Dept < 4 characters, pad with spaces
        mCourseNumber = findViewById(R.id.courseNumber);
        mCourseTitle = findViewById(R.id.courseTitle);
        mCourseDesc = findViewById(R.id.courseDesc);
        mCourseCredits = findViewById(R.id.courseCredits);
        String courseDepartment = "";
        String courseNbr = "";
        String courseNumber = "";
        String courseTitle = "";
        String courseCredits = "";
        String courseDesc = "";

        Intent intent = getIntent();

        ClassEntryModel mCurrentClassEntry = (ClassEntryModel) intent.getSerializableExtra("Current_Class_Object");
        courseDepartment = mCurrentClassEntry.getClassDept();
        courseNbr = mCurrentClassEntry.getClassCourseNbr();
        courseTitle = mCurrentClassEntry.getClassTitle();
        courseCredits = mCurrentClassEntry.getClassCredits();
        courseDesc = mCurrentClassEntry.getClassDesc();

        courseNumber = courseDepartment + courseNbr;
        mCourseNumber.setText(courseNumber);
        mCourseTitle.setText(courseTitle);
        mCourseDesc.setText(courseDesc);
        mCourseCredits.setText(courseCredits + " Credits");

    }
}